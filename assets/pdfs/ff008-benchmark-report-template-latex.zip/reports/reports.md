# Performance reports

## Report format
1. The project number and names of the user, department/college and university.
2. Names of the RSE team working on the project.
3. A brief description of the project. For example, its background and intended applications.
4. Programming language, parallel architecture (OpenMP/OpenMPI/GPU) and the list of dependencies.
5. Profiling stats at the beginning of the project.
6. Profiling stats after optimisations and improvements.

## User input
The user must provide
1. working source code
2. the list of dependencies
3. a couple of test cases
    * a small test case for quick testing of the code
    * a test case with medium complexity for performing scalability studies, only for OpenMP/MPI-based applciations.


## List of statistics to be included in the profiling report
We will choose the best possible features from the following list
depending on the application.
* Call graph with inclusive/exclusive timings
* Hot-spots - top 5 time-consuming functions
* For MPI
    * time for communication
    * time for computing
    * time spent in barriers
* For OpenMP
    * Scaling study for one user-provided test case
    * Blocking/race conditions
    * Top five time-consuming loops/functions
* Input/Output
    * Number of I/O system calls per unit time
    * Average bandwidth


## Tools
We can use any of the following tools depending on the applciation.
* TAU  (Paraprof Visualiser)
* Score-P/Scalasca  (Cube/Paraprof Visualiser)
* Intel VTune
* Arm-forge
* Matlab and Octave (using the built in profiling tools). 


## Sample profiling stats

![Score-P profile 1](./figures/cylinder3d-level1-nproc10-scorep-profile-stats-00.png)

![Score-P profile 1](./figures/cylinder3d-level1-nproc10-scorep-profile-stats-node1.png)

![Score-P profile 1](./figures/cylinder3d-level1-nproc10-scorep-profile-stats-node1.png)


